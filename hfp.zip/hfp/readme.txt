=== HFP Assignment 3 ===
Contributors: Ashley Ng, Ali Waters, Harbani Kaur
Tags: widget, plugin, shortcode, custom post type, custom
Stable tag: stable
License URI: http://phoenix.sheridanc.on.ca/~ccit3432

hfp is a WordPress plugin that adds a custom post type, a widget, and a shortcode. 
== Description ==

The widget will display a custom post type (the latest recent posts) and should display the featured image or each post. This widget works without needing any additional code of files outside of the plugin folder and will work with anything theme.

The shortcode should display a selection of posts from the custom post type (latest posts). You can 


== Installation ==

1. Upload `hfp.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Choose how many posts you want to show in the Widgets page and click save
4. All done!


== Changelog ==
v1.0 - Initial release.

